/* $begin bar2 */
/* bar2.c */ 
int x = 15213; 

void f()  
{ 
} 
/* $end bar2 */
