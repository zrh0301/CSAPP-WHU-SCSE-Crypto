# Linklab实验报告

张睿恒 2024302182001

## 一、摘要

        本总结共分文五个部分：摘要、实验前对编译的理解、实验内容、实验后对链接的理解、总结。其中实验内容是本次实验的主体：通过编译链接不同的C语言源文件对链接过程进行探讨；借助objdump与readelf阅读可执行文件的不同内容；了解了几种经典的链接时错误。

## 二、实验前对链接的理解

        在实验开始前，我对链接的理解主要是这样的：链接是高级语言程序编译成为可执行文件的重要部分之一，主要负责将不同的.o文件和库组合成一个可执行文件。主要任务是符号解析和重定位。其中符号解析是确定每个符号（包括函数名、变量名甚至文件名）的含义，重定位是调整代码段和数据段在内存中的地址。符号又分为强符号和弱符号，其中强符号是指以初始化的全局变量或函数名；弱符号则是未初始化的全局符号。在目前编译器默认的-fno-common编译选项中，多个同名弱符号被视作是warning。而重定位中一个重要的部分就是寻址。在目前的编译器中，默认打开了编译选项-fpic，用来生成“位置无关代码“。

## 三、实验内容

### 1. 构建prog

```bash
# 首先是编译阶段，利用gcc命令
gcc -Og -o main.o main.c sum.c # 将main.c和sum.c编译链接成main.o文件
gcc -Og -o sum.o sum.c main.c
gcc -Og -S main.s main.c # 将main.c 编译成机器码(汇编)
# gcc -Wall -Og -o prog sum.o main.o
# 这条指令原本出现在实验文档上，但操作中遇到了报错（如图1-1所示，无法将.o文件作为链接的输入）
gcc -Wall -Og -o prog main.c sum.c # 因此，我直接将.c文件进行编译链接来构建prog
# 下面是反编译阶段，利用objdump命令
objdump -dx main.o      > main-relo.d # 查看main函数的依赖。-dx是-d 和 -x 的简写，下同
objdump -dx -j .data main.o > maindata-relo.d # -j 是主要针对某个section进行输出，比如这条命令是只查看.data字段的部分
readelf -s main.o          > mainsym.d # readelf命令是用来查看elf文件的一些细节内容。elf文件就是可执行文件的一种通用格式
# -s 命令选项是用来读取符号表的
objdump -dx sum.o      > sum-relo.d
objdump -dx -j .data sum.o  > sumdata-relo.d
objdump -dx prog       > prog-exe.d
objdump -dx -j .data prog  > progdata-exe.d 
```

        下面两幅图是实验过程中构建的具体步骤。其中显示了链接.o文件的报错以及prog的构建过程

<img title="图1-1" src="file:///home/zrheng/Documents/Homework_CSAPP/Linklab/1-1.png" alt="" data-align="center">

![图1-2](/home/zrheng/Documents/Homework_CSAPP/Linklab/1-2.png)

### 2.在编译时构建静态链接库

```bash
gcc -Wall -Og -c main2.c addvec.c multvec.c # 仅生成编译后的文件，而不进行链接
ar rcs libvector.a addvec.o multvec.o
gcc -Wall -Og -static -o prog2c main2.c libvector.a # 值得注意的，在文档中好像把字母o打成了数字0。
gcc -Wall -Og -static -o prog2c main2.c -L. -lvector
```

        在这里解释一下ar命令的后面3个options（因为太长注释写不下）：r代表如果这个lib中已经有内容了，那么用后面的新的文件来代替之前的老的；c代表着创建一个新的lib（如果没有已经存在的的话）；s代表着给这个lib添加一个索引，这样后续编译的时候会快。因此，rcs可以看作是replace,create,sort的缩写。值得注意的是，虽然看起来似乎用了ar这个和压缩包相关的命令，但其实rcs options更多的是在用makefile之类的文件进行编译时用的。

        下图是实验过程中构建静态链接库的具体步骤。

<img src="file:///home/zrheng/Documents/Homework_CSAPP/Linklab/2-1.png" title="" alt="" data-align="center">

### 3.在加载时构建共享链接库

```bash
gcc -Wall -Og -o prog2l main2.c ./libvector.so # 在第一次完成的时候，报错“没有找到libvector.so库”
# 后来发现，确实需要自己构建libvector.so这个库。具体构建方法可以参考第四个part
objdump -dx main2.o      > main2-relo.d # 这些同理，不再赘述
objdump -dx prog2l > prog2l-exe.d
objdump -xs -j .data -j .got prog2l > prog2ldata-exe.d # 这块用到了-s这个命令，是用来输出多个section的
```

        下面给出实验过程中的贴图。

![](/home/zrheng/Documents/Homework_CSAPP/Linklab/3-1.png)

### 4. 在运行时构建共享链接库

```bash
gcc -Wall -Og -rdynamic -o prog2r dll.c -ldl # 关于rdynamic 这个编译选项在下面有详细的即使
gcc -Wall -Og -shared -fpic -o libvector.so addvec.c multvec.c
objdump -xd libvector.so > libvector-relo.d
objdump -xRr -j .data -j .got.plt -j dela.dtn -j rela.plt libvector.so > libvectordata-relo.d
```

        在这里首先解释一下gcc编译选项rdynamic是什么意思：rdynamic是--export-dynamic的简写，主要作用是用来链接共享库。当创建一个动态链接程序的时候，这个编译选项会将所有的符号加入到符号表里面。

        再解释一下构建libvector.so的过程：加入-fpic选项，意味着构建了一个不依赖特定地址而“位置无关”（position independent）的机器码。以jump为例

```shell
100:cmp reg1,reg2
101:jmpe current+10

111:NOP
```

这段代码不论在地址为100还是1000都会正常工作。这对于构建一个共享库来说是很好的，因为每次链接时，他都会被重定位到内存的不同地址。采用这种“内存独立”的编译方式便于每次链接。

        下面给出实验过程中的贴图

<img src="file:///home/zrheng/Documents/Homework_CSAPP/Linklab/4-1.png" title="" alt="" data-align="center">

### 5.查看符号表的练习

    **P1**  

        先看programme header table，可以看到是一个“位置无关”的可执行文件（“位置无关”（position-independent）在上一个part中有描述），有13个header。后面给出了每个header的地址。

<img src="file:///home/zrheng/Documents/Homework_CSAPP/Linklab/5-1.png" title="" alt="" data-align="center">

        然后查看一下符号表，一共有40个符号。其中从0-18号是链接器内部产生的局部变量。符号表中包括变量的大小、类型（对象、函数、文件等）、名字等。

<img src="file:///home/zrheng/Documents/Homework_CSAPP/Linklab/5-2.png" title="" alt="" data-align="center">

        接下来是节表。p1一共有29个节。

<img src="file:///home/zrheng/Documents/Homework_CSAPP/Linklab/5-3.png" title="" alt="" data-align="left">

    **P3**

        先看programme header table，p3也包含13个header，入口是在0x1040位置的地址。

<img src="file:///home/zrheng/Pictures/Screenshots/5-4.png" title="" alt="" data-align="center">

        然后查看一下符号表。可以看到，有42个不同的符号。

<img src="file:///home/zrheng/Documents/Homework_CSAPP/Linklab/5-5.png" title="" alt="" data-align="left">

        最后是节表，一共29个节。

<img src="file:///home/zrheng/Documents/Homework_CSAPP/Linklab/5-6.png" title="" alt="" data-align="center">    **foobar3**

        由于长度关系，后续的部分大同小异，就不贴图了，仅以语言叙述。

        foo3的错误原因是"x“被定义了两次。multiple definition of `x'; /tmp/cc9TdmbJ.o:(.data+0x0): first defined here。

    **foobar4**

        错误原因是一样的：/usr/bin/ld: /tmp/ccnNjysb.o:(.bss+0x0): multiple definition of `x'; /tmp/ccMqo6Ul.o:(.bss+0x0): first defined here。弱符号x是被重定义了两边

    **foobar5**

        这个部分很有意思，x的地址的值（原谅我采用这个抽象的表述）被意外的重写了。在foo里面，x被定义成了整形的变量而在bar中又定义了一个double的x。由于bar中的定义是弱符号（没有初始化）而foo中的定义是强符号，导致链接器在解析的时候直接将bar中的double的x“当成”的在foo中定义的int的x。这就导致了在bar中对double的x进行赋值的时候，错误的赋写了int的x的地址，并同时影响了其相邻的4个字节的y的值。

### 6.链接失败

    **linkerror**

        这个错误原因是main函数用到了函数foo但是没有给出定义（存在未解析的符号）。/usr/bin/ld: /tmp/ccb1c0ZY.o: in function `main':
linkerror.c:(.text+0x9): undefined reference to `foo'

    **foobar1**        

            这个错误原因是main被定义了两次（两个强符号撞了）。/usr/bin/ld: /tmp/cc2pr75R.o: in function `main':
bar1.c:(.text+0x0): multiple definition of `main'; /tmp/cc57iA0H.o:foo1.c:(.text+0x0): first defined here

    **foobar2**

        这个错误原因是x被定义了两次（同样是两个强符号撞了）不过这次是两个已经初始化了的全局变量。/usr/bin/ld: /tmp/ccPDdUq7.o:(.data+0x0): multiple definition of `x'; /tmp/ccB3MOUG.o:(.data+0x0): first defined here

### 四、实验后对链接的理解

        本次实验之后，我对之前被我忽略的调库过程有了新的认识。

        静态链接库的构建与使用：在实验中，我们通过 ar 工具创建了静态链接库，并将其链接到可执行文件中。这一过程让我明白了静态库的本质：它实际上是一个包含多个目标文件的归档文件，在链接时会被提取出来参与符号解析。

        动态链接的灵活性：动态链接库在运行时加载的特性使其非常适合于需要频繁更新的场景。实验中对比了静态链接和动态链接的行为差异，让我认识到动态链接的优势，例如减少可执行文件的体积和提高库的复用性。

        符号冲突的处理：通过分析 foo1.o 和 bar1.o 等案例，我了解到当多个目标文件中存在同名符号时，链接器会根据符号的强弱属性进行决策。如果出现两个强符号冲突，则会导致链接失败。

### 五、实验总结

        本次实验通过一系列具体的操作，让我从理论到实践全面了解了链接的过程及其实现细节。我熟悉了 ELF 文件的各个组成部分，包括头部信息、程序头部表、节区表、符号表等。理解了静态链接和动态链接的区别：静态链接适合于独立性强、不需要频繁更新的应用，而动态链接则更适合于需要模块化设计和资源节约的场景。实验中对比两者的优缺点，使我能够根据实际需求选择合适的链接方式。同时，我在亲自动手操作中理解了程序从高级语言一步步变成可执行文件的过程。这对我以后高效的写多文件程序打下了一个很好的理论基础。最后，我了解了不同的编译链接选项，使我对程序的编译、链接、运行机制有了更好的了解。
