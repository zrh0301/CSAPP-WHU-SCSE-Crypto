/* $begin foo1 */
/* foo1.c */ 
int main()  
{ 
    return 0;
} 
/* $end foo1 */
