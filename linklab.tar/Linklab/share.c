int myglobal=128;

int func()
{
    return myglobal;
}

