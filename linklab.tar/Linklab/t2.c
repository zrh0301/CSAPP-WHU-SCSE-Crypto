int x;

foo()
{
}
