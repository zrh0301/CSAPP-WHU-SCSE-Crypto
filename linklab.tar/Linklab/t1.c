int main()
{
    static int x=0;
    static int y;
    static int z=1;
    return 0;
}
