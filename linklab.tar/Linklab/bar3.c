/* $begin bar3 */
/* bar3.c */ 
int x; 
 
void f()  
{ 
    x = 15212; 
} 
/* $end bar3 */
