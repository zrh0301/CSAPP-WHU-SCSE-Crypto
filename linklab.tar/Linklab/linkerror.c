/* $begin linkerror */
void foo(void);

int main() {
    foo();
    return 0;
}
/* $end linkerror */
