/* $begin bar1 */
/* bar1.c */ 
int main()  
{ 
    return 0;
} 
/* $end bar1 */
 
