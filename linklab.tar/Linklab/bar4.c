/* $begin bar4 */
/* bar4.c */ 
int x; 
 
void f()  
{ 
    x = 15212; 
} 
/* $end bar4 */
