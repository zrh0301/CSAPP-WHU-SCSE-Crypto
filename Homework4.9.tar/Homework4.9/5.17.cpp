void *word_memset(void *s, int c, size_t n){
    if (n < K){
        size_t cnt = 0;
        unsigned char *schar = s;
        while (cnt < n){
            *schar++ = (unsigned char)c;
            cnt++;
        }
    }
    else{
        unsigned long word = 0;
        for (int i = 0; i < K; ++i){
            word <<= K*CHAR_BIT;
            word += (unsigned char)c;
        }
  
        size_t cnt = 0;
        unsigned long *slong = s;
        while (cnt < n){
            *slong++ = word;
            cnt += K;
        }
  
        unsigned char *schar = slong;
        while (cnt < n){
            *schar++ = (unsigned char)c;
            cnt++;
        }
    }
    return s;
  }