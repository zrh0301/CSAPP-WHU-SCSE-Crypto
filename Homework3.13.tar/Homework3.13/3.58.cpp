long decode2(long x,long y,long z){//x in %rdi, y in %rsi, z in %rdx
    z-=y;
    z*=x;
    long ans=z;
    ans<<=63;
    ans>>=63;
    ans^=x;
    return ans;
}

/*
decode2:
    subq %rdx, %rsi
    imulq %rsi, %rdi
    movq %rsi, %rax
    shlq $63, %rax
    sarq $63, %rax
    xorq %rdi, %rax
    ret
*/