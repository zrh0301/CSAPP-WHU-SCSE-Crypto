#include <stdio.h>

void good_echo(void){
    const int SIZE = 100;
    char buf[SIZE];
    while(1){
        char* p=fgets(buf,SIZE,stdin);
        if(p==NULL){
            break;
        }
        printf("%s",p);
    }
    return;
}
int main(){
    good_echo();
    return 0;
}
