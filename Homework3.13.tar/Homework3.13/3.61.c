long cread(long *xp){
    return (!xp?0:*(xp));
}